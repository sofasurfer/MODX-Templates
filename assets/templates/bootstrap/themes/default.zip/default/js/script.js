
/* 
* Load dynamic CSS files 
* If not already exists
*/
if( jQuery && !jQuery.getCSS ){
	jQuery.getCSS = function( url, media ) {
		if( $("link[href$='"+url+"']").length > 0 ){
			return true;
		}else{
			jQuery( document.createElement('link') ).attr({
				href: url,
				media: media || 'screen',
				type: 'text/css',
				rel: 'stylesheet'
			}).appendTo('head');
		}
	};
}



// NOTICE!! DO NOT USE ANY OF THIS JAVASCRIPT
// IT'S ALL JUST JUNK FOR OUR DOCS!
// ++++++++++++++++++++++++++++++++++++++++++

!function ($) {

  $(function(){

    // Disable certain links in docs
    $('section [href^=#]').click(function (e) {
      e.preventDefault()
    })

    // make code pretty
    window.prettyPrint && prettyPrint()

    // add-ons
    $('.add-on :checkbox').on('click', function () {
      var $this = $(this)
        , method = $this.attr('checked') ? 'addClass' : 'removeClass'
      $(this).parents('.add-on')[method]('active')
    })

    // position static twipsies for components page
    if ($(".twipsies a").length) {
      $(window).on('load resize', function () {
        $(".twipsies a").each(function () {
          $(this)
            .tooltip({
              placement: $(this).attr('title')
            , trigger: 'manual'
            })
            .tooltip('show')
          })
      })
    }


    // add tipsies to grid for scaffolding
    if ($('#grid-system').length) {
      $('#grid-system').tooltip({
          selector: '.show-grid > div'
        , title: function () { return $(this).width() + 'px' }
      })
    }
	
    // fix sub nav on scroll
    var $win = $(window)
      , $nav = $('.subnav')
      , navTop = $('.subnav').length && $('.subnav').offset().top - 40
      , isFixed = 0

    processScroll()

    // hack sad times - holdover until rewrite for 2.1
    $nav.on('click', function () {
		if (!isFixed) setTimeout(function () {  $win.scrollTop($win.scrollTop() - 47) }, 10);     
    })

    $win.on('scroll', processScroll)

    function processScroll() {
		var i, scrollTop = $win.scrollTop()
		if (scrollTop >= navTop && !isFixed) {
			isFixed = 1
			$nav.addClass('subnav-fixed')
		} else if (scrollTop <= navTop && isFixed) {
			isFixed = 0
			$nav.removeClass('subnav-fixed')
		}
      
		return false;

    }
	$('.subnav a').click(function () {
		$('body,html').animate({
			scrollTop:  $( $(this).attr('href') ).offset().top - 100
		}, 800, 'easeOutExpo');
		return false;
	});    

	// Back to top
	$('#back-top').hide();
	$(function () {
		$(window).scroll(function () {
			if ($(this).scrollTop() > 280) {
				$('#back-top').fadeIn();
			} else {
				$('#back-top').fadeOut();
			}
		});
		$('#back-top a').click(function () {
			$('body,html').animate({
				scrollTop: 0
			}, 800, 'easeOutExpo');
			return false;
		});
	});
	
	/* 
	 * Set ThumbList 
	*/
	$('.over .thumbnail .caption').css('top','100%');
	$('.over .thumbnail a').hover(function(){
		$(".caption", this).stop().animate({top:'50%'},{queue:false,duration:160});
	}, function() {
		$(".caption", this).stop().animate({top: '100%' },{queue:false,duration:160});
	});


    // tooltip demo
    $("a[rel=tooltip]").tooltip();
    $("a[rel=popover]").popover();
    
    

    // popover demo
    $(".thumbnail a[rel=popover]")
      .popover({'placement':'bottom'})
      .click(function(e) {
        e.preventDefault()
      })
      
    // button state demo
    $('#fat-btn')
      .click(function () {
        var btn = $(this)
        btn.button('loading')
        setTimeout(function () {
          btn.button('reset')
        }, 3000)
      })

    // carousel demo
    $('.carousel').carousel()

    // javascript build logic
    var inputsComponent = $("#components.download input")
      , inputsPlugin = $("#plugins.download input")
      , inputsVariables = $("#variables.download input")

    // toggle all plugin checkboxes
    $('#components.download .toggle-all').on('click', function (e) {
      e.preventDefault()
      inputsComponent.attr('checked', !inputsComponent.is(':checked'))
    })

    $('#plugins.download .toggle-all').on('click', function (e) {
      e.preventDefault()
      inputsPlugin.attr('checked', !inputsPlugin.is(':checked'))
    })

    $('#variables.download .toggle-all').on('click', function (e) {
      e.preventDefault()
      inputsVariables.val('')
    })

    // request built javascript
    $('.download-btn').on('click', function () {

      var css = $("#components.download input:checked")
            .map(function () { return this.value })
            .toArray()
        , js = $("#plugins.download input:checked")
            .map(function () { return this.value })
            .toArray()
        , vars = {}
        , img = ['glyphicons-halflings.png', 'glyphicons-halflings-white.png']

    $("#variables.download input")
      .each(function () {
        $(this).val() && (vars[ $(this).prev().text() ] = $(this).val())
      })

      $.ajax({
        type: 'POST'
      , url: /\?dev/.test(window.location) ? 'http://localhost:3000' : 'http://bootstrap.herokuapp.com'
      , dataType: 'jsonpi'
      , params: {
          js: js
        , css: css
        , vars: vars
        , img: img
      }
      })
    })
    
	// Support for AJAX loaded modal window.
	// Focuses on first input textbox after it loads the window.
	$('a[data-toggle="modal"]').click(function(e) {
		e.preventDefault();
		var href = $(this).attr('href');
		var target = $(this).attr('data-target');

		if ( href.indexOf('#') == 0) {

			$(target).modal('show');
									
		} else {
				
			$.get(href, function(data) {

				$(target).empty();
				$(target).append(data);


				$(target).on('show', function(e) {	
					var modal = $(this);
					//modal.css('top', 0);
					//modal.css('left', 0);
					modal.css('margin-top', (modal.outerHeight() / 2) * -1)
					modal.css('margin-left', (modal.outerWidth() / 2) * -1);
					return this;							
				});
				$(target).on('hide', function () {
					$(this).empty();
				});				
			}).success(function() { 
				if( $('video').length > 0 ){
					//$.getScript("http://api.html5media.info/1.1.5/html5media.min.js");

					$.getCSS('/assets/templates/mediaelement/build/mediaelementplayer.min.css');
					$.getScript("/assets/templates/mediaelement/build/mediaelement-and-player.min.js", function(){

						$(target).modal('show');

						$('video').mediaelementplayer({
							enableAutosize: true,
							success: function(player, node) {
								$('#' + node.id + '-mode').html('mode: ' + player.pluginType);
							}
						});
					});

				}		
			});
		}	
		return false;
	});
	
	//$.getScript("http://api.html5media.info/1.1.5/html5media.min.js");
	if( $('video,audio').length > 0 ){
		$.getCSS('/assets/templates/mediaelement/build/mediaelementplayer.min.css');
		$.getScript("/assets/templates/mediaelement/build/mediaelement-and-player.min.js", function(){
			setTimeout(function(){
				$('video,audio').mediaelementplayer({
					success: function(player, node) {
						$('#' + node.id + '-mode').html('mode: ' + player.pluginType);
					}
				});
			}, 100);
		});
	}	
  })

// Modified from the original jsonpi https://github.com/benvinegar/jquery-jsonpi
$.ajaxTransport('jsonpi', function(opts, originalOptions, jqXHR) {
  var url = opts.url;

  return {
    send: function(_, completeCallback) {
      var name = 'jQuery_iframe_' + jQuery.now()
        , iframe, form

      iframe = $('<iframe>')
        .attr('name', name)
        .appendTo('head')

      form = $('<form>')
        .attr('method', opts.type) // GET or POST
        .attr('action', url)
        .attr('target', name)

      $.each(opts.params, function(k, v) {

        $('<input>')
          .attr('type', 'hidden')
          .attr('name', k)
          .attr('value', typeof v == 'string' ? v : JSON.stringify(v))
          .appendTo(form)
      })

      form.appendTo('body').submit()
    }
  }
})

}(window.jQuery);

